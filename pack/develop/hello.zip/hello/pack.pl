title('Hello World').
version('1.0.0').

home('http://www.jekejeke.ch/').
author('(c) 2019, XLOG Technologies GmbH, Switzerland').

icon('images/hello.png').