/**
 * Prolog text cities from Chat80 as a sub module.
 *
 * Warranty & Liability
 * To the extent permitted by applicable law and unless explicitly
 * otherwise agreed upon, XLOG Technologies GmbH makes no warranties
 * regarding the provided information. XLOG Technologies GmbH assumes
 * no liability that any problems might be solved with the information
 * provided by XLOG Technologies GmbH.
 *
 * Rights & License
 * All industrial property rights regarding the information - copyright
 * and patent rights in particular - are the sole property of XLOG
 * Technologies GmbH. If the company was not the originator of some
 * excerpts, XLOG Technologies GmbH has at least obtained the right to
 * reproduce, change and translate the information.
 *
 * Reproduction is restricted to the whole unaltered document. Reproduction
 * of the information is only allowed for non-commercial uses. Selling,
 * giving away or letting of the execution of the library is prohibited.
 * The library can be distributed as part of your applications and libraries
 * for execution provided this comment remains unchanged.
 *
 * Restrictions
 * Only to be distributed with programs that add significant and primary
 * functionality to the library. Not to be distributed with additional
 * software intended to replace any components of the library.
 *
 * Trademarks
 * Jekejeke is a registered trademark of XLOG Technologies GmbH.
 */

/**
 * Obtained rights comment in Prolog text and text from LICENSE file:
 *
 * @(#)cities.pl	24.1 2/23/88
 *
 * Copyright 1986, Fernando C.N. Pereira and David H.D. Warren,
 *
 * All Rights Reserved
 *
 * This program may be used, copied, altered or included in other programs
 * only for academic purposes and provided that the authorship of the
 * initial program is acknowledged. Use for commercial purposes without the
 * previous written agreement of the authors is forbidden.
 */

:- if(current_prolog_flag(dialect,jekejeke)).

:- package(library(database)).

:- endif.

:- module(cities, [city/3]).

% Facts about cities.
% ------------------

city(belle_mead, united_states, 8).
city(athens, greece, 1368).
city(bangkok, thailand, 1178).
city(barcelona, spain, 1280).
city(berlin, east_germany, 3481).
city(birmingham, united_kingdom, 1112).
city(bombay, india, 2839).
city(brussels, belgium, 986).
city(bucharest, romania, 1237).
city(budapest, hungary, 1757).
city(buenos_aires, argentina, 3404).
city(cairo, egypt, 2373).
city(calcutta, india, 2549).
city(canton, china, 1496).
city(caracas, venezuela, 488).
city(chicago, united_states, 3621).
city(chungking, china, 1100).
city(dairen, china, 544).
city(delhi, india, 1744).
city(detroit, united_states, 1850).
city(glasgow, united_kingdom, 1090).
city(hamburg, west_germany, 1700).
city(harbin, china, 760).
city(hongkong_city, hongkong, 2440).
city(hyderabad, india, 1086).
city(istanbul, turkey, 1215).
city(jakarta, indonesia, 533).
city(johannesburg, south_africa, 880).
city(karachi, pakistan, 1126).
city(kiev, soviet_union, 991).
city(kobe, japan, 765).
city(kowloon, china, 547).
city(kyoto, japan, 1204).
city(leningrad, soviet_union, 2800).
city(lima, peru, 835).
city(london, united_kingdom, 8346).
city(los_angeles, united_states, 1970).
city(madras, india, 1416).
city(madrid, spain, 1700).
city(manila, philippines, 1025).
city(melbourne, australia, 1595).
city(mexico_city, mexico, 3796).
city(milan, italy, 1269).
city(montreal, canada, 1109).
city(moscow, soviet_union, 4800).
city(mukden, china, 1551).
city(nagoya, japan, 1337).
city(nanking, japan, 1020).
city(naples, italy, 1012).
city(new_york, united_states, 7795).
city(osaka, japan, 2547).
city(paris, france, 2850).
city(peking, china, 2031).
city(philadelphia, united_states, 2072).
city(pusan, south_korea, 474).
city(rio_de_janeiro, brazil, 2413).
city(rome, italy, 1760).
city(saigon, vietnam, 695).
city(santiago, chile, 1350).
city(sao_paulo, brazil, 2228).
city(seoul, south_korea, 1446).
city(shanghai, china, 5407).
city(sian, china, 629).
city(singapore_city, singapore, 1264).
city(sydney, australia, 1898).
city(tehran, iran, 1010).
city(tientsin, china, 1795).
city(tokyo, japan, 8535).
city(toronto, canada, 668).
city(vienna, austria, 1766).
city(warsaw, poland, 965).
city(yokohama, japan, 1143).
city(toronto, canada, 668).
city(vienna, austria, 1766).
city(warsaw, poland, 965).
city(yokohama, japan, 1143).

